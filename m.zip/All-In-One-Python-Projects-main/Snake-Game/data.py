from scoreboard import Score
score = Score()
HighScore = score.high_score