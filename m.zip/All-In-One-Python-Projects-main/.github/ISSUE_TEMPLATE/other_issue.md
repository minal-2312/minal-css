---
name: "Other"
about: "Use this template for any other issues or inquiries."
title: "Other Issue Title"
labels: ["question", "other"]
---

## Description
Please provide a detailed description of your inquiry or issue.

## Context
Add any relevant context or background information that may help in addressing your request.

## Additional Information
If applicable, include any additional information, screenshots, or references.
